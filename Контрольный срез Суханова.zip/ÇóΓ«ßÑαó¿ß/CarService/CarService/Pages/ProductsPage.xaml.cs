﻿using CarService.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductsPage.xaml
    /// </summary>
    public partial class ProductsPage : Page
    {
        public ProductsPage()
        {
            InitializeComponent();
            DGridProducts.ItemsSource = GRUSHSERVICEEntities.GetContext().Products.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GRUSHSERVICEEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridProducts.ItemsSource = GRUSHSERVICEEntities.GetContext().Products.ToList();
            }
        }

        private void BtnRegistration_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new RegistrationPage());
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ClientsPage());
        }

        private void BtnServices_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ServicesPage());
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditProductsPage((sender as Button).DataContext as Products));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditProductsPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var productsForRemoving = DGridProducts.SelectedItems.Cast<Products>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {productsForRemoving.Count()} запись?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GRUSHSERVICEEntities.GetContext().Products.RemoveRange(productsForRemoving);
                    GRUSHSERVICEEntities.GetContext().SaveChanges();
                    MessageBox.Show("Запись удалена!");

                    DGridProducts.ItemsSource = GRUSHSERVICEEntities.GetContext().Products.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
