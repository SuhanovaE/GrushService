﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditRegistrationPage.xaml
    /// </summary>
    public partial class AddEditRegistrationPage : Page
    {
        private Registration _currentRegistration = new Registration();

        public AddEditRegistrationPage(Registration selectedRegistration)
        {
            InitializeComponent();
            if (selectedRegistration != null)
                _currentRegistration = selectedRegistration;
            //создаем контекст
            DataContext = _currentRegistration;

            CmbClients.ItemsSource = GRUSHSERVICEEntities.GetContext().Clients.ToList();
            CmbClients.SelectedValuePath = "idClients";
            CmbClients.DisplayMemberPath = "FIO";

            CmbServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.ToList();
            CmbServices.SelectedValuePath = "idServices";
            CmbServices.DisplayMemberPath = "serviceName";

            CmbProducts.ItemsSource = GRUSHSERVICEEntities.GetContext().Products.ToList();
            CmbProducts.SelectedValuePath = "idProducts";
            CmbProducts.DisplayMemberPath = "productName";

        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (_currentRegistration.fk_client == null)
                error.AppendLine("Укажите клиента");
            if (_currentRegistration.fk_service == null)
                error.AppendLine("Укажите услугу");
            if (_currentRegistration.documents == null)
                error.AppendLine("Укажите документы");
            if (_currentRegistration.fk_product == null)
                error.AppendLine("Укажите продукт");
            if (_currentRegistration.startDate == null)
                error.AppendLine("Укажите дату начала");

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentRegistration.idRegistration == 0)
                GRUSHSERVICEEntities.GetContext().Registration.Add(_currentRegistration); //добавить в контекст
            try
            {
                GRUSHSERVICEEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новая запись на услугу добавлена");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
