﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditServicesPage.xaml
    /// </summary>
    public partial class AddEditServicesPage : Page
    {
        private Services _currentServices = new Services();

        public AddEditServicesPage(Services selectedServices)
        {
            InitializeComponent();
            if (selectedServices != null)
                _currentServices = selectedServices;
            //создаем контекст
            DataContext = _currentServices;     
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (_currentServices.serviceName == null)
                error.AppendLine("Укажите название услуги");
            if (_currentServices.servicePrice == null)
                error.AppendLine("Укажите цену услуги");
            if (_currentServices.executionDuration == null)
                error.AppendLine("Укажите продолительность выполнения");
            if (_currentServices.executionDuration < 0)
                error.AppendLine("Продолжительность выполнения не может быть отрицательным значением");
            
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentServices.idServices == 0)
                GRUSHSERVICEEntities.GetContext().Services.Add(_currentServices); //добавить в контекст
            try
            {
                GRUSHSERVICEEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новая услуга добавлена");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
