﻿using CarService.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService.Pages
{
    /// <summary>
    /// Логика взаимодействия для ClientsPage.xaml
    /// </summary>
    public partial class ClientsPage : Page
    {
        public ClientsPage()
        {
            InitializeComponent();
            DGridClients.ItemsSource = GRUSHSERVICEEntities.GetContext().Clients.ToList();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GRUSHSERVICEEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridClients.ItemsSource = GRUSHSERVICEEntities.GetContext().Clients.ToList();
            }
        }

        private void BtnRegistration_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new RegistrationPage());
        }

        private void BtnProducts_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ProductsPage());
        }

        private void BtnServices_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ServicesPage());
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditClientsPage((sender as Button).DataContext as Clients));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditClientsPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var clientsForRemoving = DGridClients.SelectedItems.Cast<Clients>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {clientsForRemoving.Count()} запись?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GRUSHSERVICEEntities.GetContext().Clients.RemoveRange(clientsForRemoving);
                    GRUSHSERVICEEntities.GetContext().SaveChanges();
                    MessageBox.Show("Запись удалена!");

                    DGridClients.ItemsSource = GRUSHSERVICEEntities.GetContext().Clients.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
