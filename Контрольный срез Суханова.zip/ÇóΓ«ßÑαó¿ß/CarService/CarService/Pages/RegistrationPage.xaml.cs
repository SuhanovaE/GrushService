﻿using CarService.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegistrationPage.xaml
    /// </summary>
    public partial class RegistrationPage : Page
    {
        public RegistrationPage()
        {
            InitializeComponent();
            DGridRegistration.ItemsSource = GRUSHSERVICEEntities.GetContext().Registration.ToList();
        }

        private void BtnProducts_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ProductsPage());
        }

        private void BtnServices_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ServicesPage());
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ClientsPage());
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditRegistrationPage((sender as Button).DataContext as Registration));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditRegistrationPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var registrationForRemoving = DGridRegistration.SelectedItems.Cast<Registration>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {registrationForRemoving.Count()} запись?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GRUSHSERVICEEntities.GetContext().Registration.RemoveRange(registrationForRemoving);
                    GRUSHSERVICEEntities.GetContext().SaveChanges();
                    MessageBox.Show("Запись удалена!");

                    DGridRegistration.ItemsSource = GRUSHSERVICEEntities.GetContext().Registration.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GRUSHSERVICEEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridRegistration.ItemsSource = GRUSHSERVICEEntities.GetContext().Registration.ToList();
            }
        }
    }
}
