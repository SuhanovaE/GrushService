﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditProductsPage.xaml
    /// </summary>
    public partial class AddEditProductsPage : Page
    {
        private Products _currentProducts = new Products();

        public AddEditProductsPage(Products selectedProducts)
        {
            InitializeComponent();
            if (selectedProducts != null)
                _currentProducts = selectedProducts;
            //создаем контекст
            DataContext = _currentProducts;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (_currentProducts.productName == null)
                error.AppendLine("Укажите название продукта");
            if (_currentProducts.productPrice == null || _currentProducts.productPrice<1)
                error.AppendLine("Укажите цену продукта");
            if (_currentProducts.description == null)
                error.AppendLine("Укажите описание продукта");           

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentProducts.idProducts == 0)
                GRUSHSERVICEEntities.GetContext().Products.Add(_currentProducts); //добавить в контекст
            try
            {
                GRUSHSERVICEEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый продукт добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
