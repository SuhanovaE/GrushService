﻿using CarService.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService.Pages
{
    /// <summary>
    /// Логика взаимодействия для ServicesPage.xaml
    /// </summary>
    public partial class ServicesPage : Page
    {
        public ServicesPage()
        {
            InitializeComponent();
            DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.ToList();
        }

        private void BtnProducts_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ProductsPage());
        }

        private void BtnRegistration_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new RegistrationPage());
        }

        private void BtnClients_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ClientsPage());
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditServicesPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var servicesForRemoving = DGridServices.SelectedItems.Cast<Services>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {servicesForRemoving.Count()} запись?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    GRUSHSERVICEEntities.GetContext().Services.RemoveRange(servicesForRemoving);
                    GRUSHSERVICEEntities.GetContext().SaveChanges();
                    MessageBox.Show("Запись удалена!");

                    DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {
                GRUSHSERVICEEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.ToList();
            }
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.Where(x => x.serviceName.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.OrderBy(x => x.servicePrice).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.OrderByDescending(x => x.servicePrice).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            TxbSearch.Text = "";
            CmbFiltrPrice.SelectedIndex = -1;
            RbUp.IsChecked = false;
            RbDown.IsChecked = false;
            DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditServicesPage((sender as Button).DataContext as Services));
        }

        private void CmbFiltrPrice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltrPrice.SelectedIndex == 0)
            {
                DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.Where(x =>
                    x.servicePrice >= 0 && x.servicePrice <= 5000).ToList();
            }
            else
                if (CmbFiltrPrice.SelectedIndex == 1)
            {
                DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.Where(x =>
                    x.servicePrice >= 5001 && x.servicePrice <= 15000).ToList();
            }
            else
            {
                DGridServices.ItemsSource = GRUSHSERVICEEntities.GetContext().Services.Where(x =>
                   x.servicePrice >= 15001).ToList();
            }
        }
    }
}
