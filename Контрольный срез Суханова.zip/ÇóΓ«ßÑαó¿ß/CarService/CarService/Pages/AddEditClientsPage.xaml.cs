﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CarService.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditClientsPage.xaml
    /// </summary>
    public partial class AddEditClientsPage : Page
    {
        private Clients _currentClients = new Clients();

        public AddEditClientsPage(Clients selectedClients)
        {
            InitializeComponent();
            if (selectedClients != null)
                _currentClients = selectedClients;
            //создаем контекст
            DataContext = _currentClients;

            CmbGender.ItemsSource = GRUSHSERVICEEntities.GetContext().Gender.ToList();
            CmbGender.SelectedValuePath = "idGender";
            CmbGender.DisplayMemberPath = "gender1";

        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (_currentClients.FIO == null)
                error.AppendLine("Укажите ФИО клиента");
            if (_currentClients.fk_gender == null)
                error.AppendLine("Укажите пол клиента");
            if (_currentClients.dateOfBirth == null)
                error.AppendLine("Укажите дату рождения клиента");
            if (_currentClients.registrationDate == null)
                error.AppendLine("Укажите дату регистрации");
            if (_currentClients.email == null)
                error.AppendLine("Укажите почту клиента");
            if (_currentClients.phone == null)
                error.AppendLine("Укажите телефон клиента");
            if (_currentClients.tags == null)
                error.AppendLine("Укажите тег");

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentClients.idClients == 0)
                GRUSHSERVICEEntities.GetContext().Clients.Add(_currentClients); //добавить в контекст
            try
            {
                GRUSHSERVICEEntities.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый клиент добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
